// Establish your models relations inside this function
const initModels = () => {};

module.exports = { initModels };
