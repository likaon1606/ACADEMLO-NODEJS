console.log('Script loaded from Nodejs');
