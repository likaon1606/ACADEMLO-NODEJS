const PostDetails = () => {
	return <div></div>;
};

export default PostDetails;
