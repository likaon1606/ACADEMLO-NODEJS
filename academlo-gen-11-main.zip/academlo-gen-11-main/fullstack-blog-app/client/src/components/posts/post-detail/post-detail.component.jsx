const PostDetail = () => {
	return <div></div>;
};

export default PostDetail;
